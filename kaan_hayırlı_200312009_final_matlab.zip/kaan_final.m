clear all
diary kaan_final_odev.out
%% 1.soru a)
% fs sesin süresini belirliyor. audioread bir ses dosyasının okunmasını
% sağlar. sibel değişkenine ataadım çünkü onun üstünden işlemlerime devam
% edebilmek için. fs ise saniyeye düşen örnek sayısı. ve sound ise sesin
% dinlenmesi için gereken bir komut.

sibel = audioread("C:\Users\Kaan\Downloads\sibel.MP3");
[y,fs] = audioread("C:\Users\Kaan\Downloads\sibel.MP3");
sound(y,fs)
kaan = audioread("C:\Users\Kaan\Downloads\kaan.MP4");
[y,fs] = audioread("C:\Users\Kaan\Downloads\kaan.MP4");
sound(y,fs)
%% b)
sibel = audioread("C:\Users\Kaan\Downloads\sibel.MP3");
[y,fs] = audioread("C:\Users\Kaan\Downloads\sibel.MP3");
t=[1/fs:1/fs:length(y)/fs];
figure
plot(t,sibel)
title("Kadın Sesi")
kaan = audioread("C:\Users\Kaan\Downloads\kaan.MP4");
[y,fs] = audioread("C:\Users\Kaan\Downloads\kaan.MP4");
t=[1/fs:1/fs:length(y)/fs];
figure
plot(t,kaan)
title("Erkek Sesi")
%ses sinyalleri frekansa benziyor ve bu sinyaller artıp azalan sesin
%duyulmasına göre çizilen sinyallerdir.
%% c)
%kadın ve erkek seslerindeki en temel fark sesin ince ve kalınlığıdır.kadın
%sesinde grafikte çizilen sinyaller daha kısa  sinyaller olurken erkek
%sesinde daha uzun sinyaller görüldü.
%% d)
% bu özellikleri grafiktede net bir şekilde görebiliyoruz. kadın sesinde
% çizgiler dolgun ve kısayken erkek sesinde çizgiler ince ve daha uun
% olarak görülüyor.
%% e)
sibel = audioread("C:\Users\Kaan\Downloads\sibel.MP3");
l=length(sibel)-1;
f=0:fs/l:fs;
sibelfft=abs(fft(sibel));
figure
plot(f,sibelfft);
xlabel('Frekans (Hz)');
ylabel('büyüklük');
kaan = audioread("C:\Users\Kaan\Downloads\kaan.MP4");
n=length(kaan)-1;
f=0:fs/n:fs;
kaanfft=abs(fft(kaan));
figure
plot(f,kaanfft);
xlabel('Frekans (Hz)');
ylabel('büyüklük');
%% f)
% Harmonikler, temel frekansın katları olan frekanslarda çalışan akı ve
% gerilimlerdir.50Hz.'i temel frekans yani birinci harmonik olarak
% düşünürsek 100Hz'i ( 2x50Hz) ikinci harmonik, 150Hz'i (3x50Hz) çüncü
% harmonik, 250Hz'i beşinci harmonik, 350Hz'i yedinci harmonik olarak
% adlandırabiliriz.
% Harmonikler, bozulmuş temel dalga formunu oluşturan toplam yüksek frekans
% dalga biçimlerini ifade eder.
% Vizedeki kare sinyalleri yapmadığım için bilmiyorum.
%% g)
% Ana frekans sesi, sesin tiz bir şekilde duyulmasını ve sesin
% anlaşılmamasıdır. Harmonikler ise ana frekansın küçük genlikli ve yüksek
% frekanslı olmasından dolayı sesin tonunu daha net ve gür duyulması için
% etkili olduğundan harmonikler sesin daha net duyulmasını sağlar.
%% h)
% Bu maddeyi araştırdım ancak bir sonnuca ulaşamadım. Bir önceki öncülde ne
% demiştiktik harmonikler frekansın katlaarıyla oluşuyor. Bu nedenle
% frekans bir saniyedeki devir sayısı ve frekansın formulünden dalga hızı
% bölü dalga boyundan hesaplanıyor. Harmonik frekansın katları olduğundan
% dolayı frekans formulünün katları olarak matematiğini bu şekilde
% açıklayabildim. Başka bir bilgi bulamadım.
%% 2)
function y=ortalama(a,b,c,d)
a=en
b=boy
c=standart_sapma
d=ortalama_deger
en=input('sayı giriniz:')
boy=input('sayı giriniz:')
ortalama_deger=input('sayı giriniz:')
%% 3)
% excelde sınıf listesi oluşturdum. Bu excel dosyasını okuması için xlsread
% komutunu kullandım. fakat liste değişkeni yaptığımda çıktıda kişilerin
% ismini NAN olarak verdiği için onu  araştırdım ve alttaki "[~,~,tam]"
% değişken yaptım ve listeyi tam olarak çıktı verdi. Sonrasında soz
% değişkeni ile sizin bize göndermiş olduğunuz cümleyi soz değişkenine
% atadım. Bu değişkeni writematrix komutu ile IsimSoyisim.txt dosyası
% oluşturup entegre ettim.
liste = xlsread('siniflistesi.xlsx');
ilksatir = liste(1,:);
[~,~,tam] = xlsread('siniflistesi.xlsx')
[m n] = size(tam);
soz = ["Bu dersi almakla, bu derste bana eğitimimin bir parçası olarak yapmam için sunulan ödev, quiz, proje veya sınavlarda kendi emeğim olmayan hiçbir yazı, resim veya düşünceyi referans vermeksizin kullanmayacağıma, yardımlaşmanın yasaklandığı çalışmalarda ders hocası veya asistanı dışında hiçkimseden yardım almayacağıma şerefim üzerine söz veririm."]
writematrix(soz,"IsimSoyisim.txt","Delimiter","tab")
writematrix(ilksatir,"IsimSoyisim.txt","Delimiter","tab","WriteMod","append")
