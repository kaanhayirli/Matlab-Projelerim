%syms x komutu, x değişkenini sembolik olarak tanımlar, yani x'in gerçek sayılar yerine sembolik ifadeler içerebileceği anlamına gelir.
syms x;

%Kodun ilk satırlarında sembolik bir değişken olan "x" tanımlanır ve x^10 - 1 fonksiyonu "f" olarak tanımlanır.
f = x^10 - 1;

%a, b ve e değişkenleri, kullanıcı tarafından tanımlanan başlangıç değerleri ve hata toleransını ifade eder.
a = 0; % starting point a
b = 1.3; % starting point b
e = 0; % tolerable error


%"fa" ve "fb" fonksiyonun "a" ve "b" noktalarındaki değerleri hesaplanır.
fa = eval(subs(f,x,a));
fb = eval(subs(f,x,b));


%Sonra, hata vektörü, A, B ve C değişkenleri tanımlanır.
A=[];
B=[a];
C=[]
error = [];

%False position yöntemi uygulanır. İlk olarak, kök aralığı belirlenir ve bu aralıkta bir başlangıç değeri olan 
% c, a ve b değerleri kullanılarak hesaplanır. c değeri ile f(c) hesaplanır ve ardından kök aralığı, 
% c değerine göre yeniden belirlenir. Bu işlem, kabul edilebilir hata düzeyine ulaşıncaya kadar tekrarlanır. 
% Her adımda, kök adayı ve hata vektörü güncellenir ve sonuçlar ekrana yazdırılır.
%Sonrasında döngüde yanıltma yöntemi uygulanır. 
% İlk olarak, "c" noktası "a" ve "b" noktaları arasındaki doğrunun x eksenini kestiği noktadır. 
%"fc" ise "c" noktasındaki fonksiyon değeridir. Daha sonra, her iterasyonda "a" veya "b" noktalarından biri "c" noktasına eşitlenir, 
%böylece "fc" değeri sıfıra yaklaşır ve kök bulunur. Hesaplamalar sırasında hata değeri de hesaplanır.
if fa*fb > 0 
    disp('Given initial values do not bracket the root.');
else
    c = a - (a-b) * fa/(fa-fb);
    fc = eval(subs(f,x,c));
    fprintf('\n\nxl\t\t\txu\t\t\txr\t\t\tf(c)\n');
    for i=1:20
        fprintf('%f\t%f\t%f\t%f\n',a,b,c,fc);
        plot([a  b],[fa; fb;],"b")
        hold on
        error(i) = abs(fc);
        if fa*fc< 0
            b =c;
            fb = eval(subs(f,x,b));
        else
            a =c;
            fa = eval(subs(f,x,a));
        end
        c = a - (a-b) * fa/(fa-fb);
        fc = eval(subs(f,x,c));
        if abs(fc) <= e
            fprintf('\nRoot is: %f\n', c);
            break;
        elseif i==20
            fprintf('\nMaximum number of iterations reached.\n');
        end
       A=[A,c];
       B=[B,c];
    end
    

    % hesaplanan hata değerleri grafiklerle gösterilir. 
    % İlk grafikte, yanıltma yönteminin her iterasyonunda hesaplanan hata değerleri gösterilir. 
    % İkinci grafikte ise, yanıltma yöntemi ile hesaplanan kök değerleri için bir hata yüzdesi hesaplanır 
    % ve bu hata yüzdesi diğer bir yöntemle (burada, algebrail bir yöntemle) hesaplanan hata yüzdesi ile karşılaştırılır.
    xaksis=linspace(0,1.5);  
    yaksis=xaksis.^10-1;
    hold on
    plot(xaksis, yaksis,"r")
    print -deps 1
    xlabel('Iteration');
    ylabel('Error');
    title('False Position Method');
    grid on

    figure

    Etxaksis=[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20];
    plot(Etxaksis,abs((1-A)/1*100),"b")
    xlabel('Iteration');
    ylabel('Error');
    x = 0:0.2:10;
    hold on
    for i=1:20
       C=[C,abs((B(i+1)-B(i))/B(i+1)*100)];

    
    end
    %plot fonksiyonları, sıfır noktasının yaklaşık konumunu, 
    %gerçek fonksiyonun grafiğini ve hata değerinin iterasyon sayısına göre değişimini görselleştirir.
    %legend fonksiyonu, görseller için açıklamalar ekler
    plot(Etxaksis,C,"r");
    print -deps 2
    legend('Algebraic Function','Non-Algebraic Function');

end