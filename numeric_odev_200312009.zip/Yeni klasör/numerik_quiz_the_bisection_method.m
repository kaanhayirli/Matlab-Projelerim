%syms x komutu, x değişkenini sembolik olarak tanımlar, yani x'in gerçek sayılar yerine sembolik ifadeler %içerebileceği anlamına gelir.
syms x;

% f = x^10 - 1 komutu, f fonksiyonunu tanımlar, burada f(x) = x^10 - 1 olarak belirlenir.
f = x^10 - 1;

% a, b ve e değişkenleri, kullanıcı tarafından tanımlanan başlangıç değerleri ve hata toleransını ifade eder.
a = 0; % starting point a
b = 1.3; % starting point b
e = 0; % tolerable error

% fa ve fb değişkenleri, f fonksiyonunun a ve b noktalarındaki fonksiyon değerlerini hesaplar.
fa = eval(subs(f,x,a));
fb = eval(subs(f,x,b));

% A, B ve C değişkenleri, sırasıyla c değişkeninin tuttuğu değerleri, a ve b değerlerini içerir.
A=[];
B=[a];
C=[]
error = [];

% Döngü, fa ve fb değerleri farklı işaretlerde olduğu sürece devam eder.
% Döngü, c değişkeninin değerini hesaplar ve fc değişkeninde f(c) fonksiyon değerini saklar.
% Döngü, maksimum iterasyon sayısına veya hata toleransına ulaşana kadar a, b ve c değerlerini günceller
% ve fc fonksiyon değerini hesaplar.
% error vektörü, her iterasyonda hesaplanan fc hata değerlerini içerir.
% İterasyon sayısına bağlı olarak, A ve B vektörleri, sıfır noktasının yaklaşık konumunu saklar.
if fa*fb > 0 
    disp('Given initial values do not bracket the root.');
else
    c = a - (a-b) * fa/(fa-fb);
    fc = eval(subs(f,x,c));
    fprintf('\n\nxl\t\t\txu\t\t\txr\t\t\tf(c)\n');
    for i=1:20
        fprintf('%f\t%f\t%f\t%f\n',a,b,c,fc);
        plot([a  b],[fa; fb;],"b")
        
        hold on
        error(i) = abs(fc);
        if fa*fc< 0
            b =c;
            fb = eval(subs(f,x,b));
        else
            a =c;
            fa = eval(subs(f,x,a));
        end
        c = (a+b)/2;
        fc = eval(subs(f,x,c));
        if abs(fc) <= e
            fprintf('\nRoot is: %f\n', c);
            break;
        elseif i==20
            fprintf('\nMaximum number of iterations reached.\n');
        end
       A=[A,c];
       B=[B,c];
    end
    

    % plot fonksiyonları, sıfır noktasının yaklaşık konumunu,
    % gerçek fonksiyonun grafiğini ve hata değerinin iterasyon sayısına göre değişimini görselleştirir.
    xaksis=linspace(0,1.5);  
    yaksis=xaksis.^10-1;
    hold on
    plot(xaksis, yaksis,"r")
    print -deps 3
    xlabel('Iteration');
    ylabel('Error');
    title('The Bisection Method');
    grid on

    figure

    Etxaksis=[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20];
    plot(Etxaksis,abs((1-A)/1*100),"b")
    xlabel('Iteration');
    ylabel('Error');
    hold on
    for i=1:20
       C=[C,abs((B(i+1)-B(i))/B(i+1)*100)];

    
    end
    % legend fonksiyonu, görseller için açıklamalar ekler.
    plot(Etxaksis,C,"r");
    print -deps 4
    legend('Algebraic Function','Non-Algebraic Function');

end